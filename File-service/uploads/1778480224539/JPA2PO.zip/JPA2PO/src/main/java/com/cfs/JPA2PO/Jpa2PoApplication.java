package com.cfs.JPA2PO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa2PoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jpa2PoApplication.class, args);
	}

}
