package com.cfs.JPA2PO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa2PoApplicationTests {

	@Test
	void contextLoads() {
	}

}
