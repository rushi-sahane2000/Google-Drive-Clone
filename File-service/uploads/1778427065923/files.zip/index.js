import React from 'react';
import ReactDOM from 'react-dom/client';
import FileManager from './file-manager-ui';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <FileManager />
  </React.StrictMode>
);
