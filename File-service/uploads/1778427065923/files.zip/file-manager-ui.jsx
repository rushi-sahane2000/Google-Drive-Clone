import React, { useState, useEffect } from 'react';
import { Upload, Search, Folder, File, Download, Plus, MoreVertical, Grid, List, ChevronRight, Home, X } from 'lucide-react';

// API Configuration
const API_BASE = {
  files: 'http://localhost:8081/api/files',
  folders: 'http://localhost:8082/api/folders',
  search: 'http://localhost:8083/api/search'
};

const FileManager = () => {
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);
  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showCreateFolderModal, setShowCreateFolderModal] = useState(false);
  const [breadcrumbs, setBreadcrumbs] = useState([{ id: null, name: 'Home' }]);
  const [selectedItems, setSelectedItems] = useState([]);

  useEffect(() => {
    fetchData();
  }, [currentFolderId]);

  const fetchData = async () => {
    try {
      if (currentFolderId) {
        const [filesRes, foldersRes] = await Promise.all([
          fetch(`${API_BASE.files}/folder/${currentFolderId}`),
          fetch(`${API_BASE.folders}/parent/${currentFolderId}`)
        ]);
        setFiles(await filesRes.json());
        setFolders(await foldersRes.json());
      } else {
        const [filesRes, foldersRes] = await Promise.all([
          fetch(API_BASE.files),
          fetch(API_BASE.folders)
        ]);
        const allFiles = await filesRes.json();
        const allFolders = await foldersRes.json();
        setFiles(allFiles.filter(f => !f.folderId));
        setFolders(allFolders.filter(f => !f.parentId));
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleSearch = async (query) => {
    setSearchQuery(query);
    if (!query.trim()) {
      fetchData();
      return;
    }
    
    try {
      const res = await fetch(`${API_BASE.search}?query=${encodeURIComponent(query)}`);
      const data = await res.json();
      setFiles(data.files || []);
      setFolders(data.folders || []);
    } catch (error) {
      console.error('Search error:', error);
    }
  };

  const handleFolderClick = (folder) => {
    setCurrentFolderId(folder.id);
    setBreadcrumbs([...breadcrumbs, { id: folder.id, name: folder.name }]);
  };

  const handleBreadcrumbClick = (index) => {
    const newBreadcrumbs = breadcrumbs.slice(0, index + 1);
    setBreadcrumbs(newBreadcrumbs);
    setCurrentFolderId(newBreadcrumbs[newBreadcrumbs.length - 1].id);
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('name', file.name);
    formData.append('folderId', currentFolderId || 0);

    try {
      const res = await fetch(`${API_BASE.files}/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        fetchData();
        setShowUploadModal(false);
      }
    } catch (error) {
      console.error('Upload error:', error);
    }
  };

  const handleCreateFolder = async (name) => {
    try {
      const res = await fetch(`${API_BASE.folders}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, parentId: currentFolderId })
      });
      const data = await res.json();
      if (data.success) {
        fetchData();
        setShowCreateFolderModal(false);
      }
    } catch (error) {
      console.error('Create folder error:', error);
    }
  };

  const handleDownload = async (file) => {
    try {
      const res = await fetch(`${API_BASE.files}/download/${file.id}`);
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.click();
    } catch (error) {
      console.error('Download error:', error);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="file-manager">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <div className="logo">
            <div className="logo-icon">
              <div className="logo-dot"></div>
              <div className="logo-dot"></div>
              <div className="logo-dot"></div>
            </div>
            <span className="logo-text">CloudVault</span>
          </div>
        </div>
        
        <div className="header-center">
          <div className="search-container">
            <Search size={20} />
            <input
              type="text"
              placeholder="Search files and folders..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="search-input"
            />
          </div>
        </div>

        <div className="header-right">
          <button className="btn-icon" onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}>
            {viewMode === 'grid' ? <List size={20} /> : <Grid size={20} />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="main-container">
        {/* Sidebar */}
        <aside className="sidebar">
          <div className="sidebar-section">
            <button className="sidebar-btn active" onClick={() => handleBreadcrumbClick(0)}>
              <Home size={20} />
              <span>Home</span>
            </button>
            <button className="sidebar-btn" onClick={() => setShowUploadModal(true)}>
              <Upload size={20} />
              <span>Upload</span>
            </button>
            <button className="sidebar-btn" onClick={() => setShowCreateFolderModal(true)}>
              <Plus size={20} />
              <span>New Folder</span>
            </button>
          </div>

          <div className="sidebar-divider"></div>

          <div className="sidebar-section">
            <div className="sidebar-label">Quick Access</div>
            <div className="storage-info">
              <div className="storage-bar">
                <div className="storage-used" style={{ width: '45%' }}></div>
              </div>
              <div className="storage-text">4.5 GB of 10 GB used</div>
            </div>
          </div>
        </aside>

        {/* Content Area */}
        <main className="content">
          {/* Breadcrumbs */}
          <div className="breadcrumbs">
            {breadcrumbs.map((crumb, index) => (
              <React.Fragment key={index}>
                <button
                  className={`breadcrumb ${index === breadcrumbs.length - 1 ? 'active' : ''}`}
                  onClick={() => handleBreadcrumbClick(index)}
                >
                  {crumb.name}
                </button>
                {index < breadcrumbs.length - 1 && <ChevronRight size={16} />}
              </React.Fragment>
            ))}
          </div>

          {/* Items Grid/List */}
          <div className={`items-container ${viewMode}`}>
            {folders.map(folder => (
              <div
                key={`folder-${folder.id}`}
                className="item folder-item"
                onClick={() => handleFolderClick(folder)}
              >
                <div className="item-icon">
                  <Folder size={viewMode === 'grid' ? 48 : 24} />
                </div>
                <div className="item-info">
                  <div className="item-name">{folder.name}</div>
                  {viewMode === 'list' && <div className="item-type">Folder</div>}
                </div>
                {viewMode === 'list' && (
                  <div className="item-actions">
                    <button className="btn-icon-small">
                      <MoreVertical size={16} />
                    </button>
                  </div>
                )}
              </div>
            ))}

            {files.map(file => (
              <div key={`file-${file.id}`} className="item file-item">
                <div className="item-icon">
                  <File size={viewMode === 'grid' ? 48 : 24} />
                </div>
                <div className="item-info">
                  <div className="item-name">{file.name}</div>
                  <div className="item-size">{formatFileSize(file.size)}</div>
                </div>
                {viewMode === 'list' && (
                  <div className="item-actions">
                    <button className="btn-icon-small" onClick={() => handleDownload(file)}>
                      <Download size={16} />
                    </button>
                    <button className="btn-icon-small">
                      <MoreVertical size={16} />
                    </button>
                  </div>
                )}
              </div>
            ))}

            {folders.length === 0 && files.length === 0 && (
              <div className="empty-state">
                <Folder size={64} strokeWidth={1} />
                <h3>No items here</h3>
                <p>Upload files or create folders to get started</p>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="modal-overlay" onClick={() => setShowUploadModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Upload File</h2>
              <button className="btn-icon" onClick={() => setShowUploadModal(false)}>
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <div className="upload-zone">
                <Upload size={48} strokeWidth={1} />
                <p>Choose a file to upload</p>
                <input
                  type="file"
                  onChange={handleUpload}
                  className="file-input"
                />
                <button className="btn-primary" onClick={() => document.querySelector('.file-input').click()}>
                  Select File
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Folder Modal */}
      {showCreateFolderModal && (
        <div className="modal-overlay" onClick={() => setShowCreateFolderModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create New Folder</h2>
              <button className="btn-icon" onClick={() => setShowCreateFolderModal(false)}>
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <input
                type="text"
                placeholder="Folder name"
                className="input"
                id="folder-name-input"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleCreateFolder(e.target.value);
                  }
                }}
              />
              <button
                className="btn-primary"
                onClick={() => {
                  const input = document.getElementById('folder-name-input');
                  if (input.value.trim()) {
                    handleCreateFolder(input.value);
                  }
                }}
              >
                Create Folder
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@300;400;600&family=DM+Sans:wght@400;500;700&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .file-manager {
          height: 100vh;
          display: flex;
          flex-direction: column;
          background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
          font-family: 'DM Sans', sans-serif;
          color: #1a1a2e;
        }

        /* Header */
        .header {
          height: 72px;
          background: rgba(255, 255, 255, 0.95);
          backdrop-filter: blur(20px);
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 32px;
          position: sticky;
          top: 0;
          z-index: 100;
          box-shadow: 0 2px 20px rgba(0, 0, 0, 0.02);
        }

        .header-left, .header-right {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .header-right {
          justify-content: flex-end;
        }

        .logo {
          display: flex;
          align-items: center;
          gap: 12px;
          font-family: 'Crimson Pro', serif;
          font-size: 24px;
          font-weight: 600;
          color: #1a1a2e;
        }

        .logo-icon {
          width: 36px;
          height: 36px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 3px;
          padding: 8px;
        }

        .logo-dot {
          width: 6px;
          height: 6px;
          background: white;
          border-radius: 50%;
          animation: pulse 2s ease-in-out infinite;
        }

        .logo-dot:nth-child(2) {
          animation-delay: 0.2s;
        }

        .logo-dot:nth-child(3) {
          animation-delay: 0.4s;
        }

        @keyframes pulse {
          0%, 100% { opacity: 0.4; transform: scale(0.9); }
          50% { opacity: 1; transform: scale(1.1); }
        }

        .header-center {
          flex: 2;
          display: flex;
          justify-content: center;
        }

        .search-container {
          width: 100%;
          max-width: 600px;
          position: relative;
          display: flex;
          align-items: center;
          gap: 12px;
          background: #f8f9fa;
          border-radius: 12px;
          padding: 12px 20px;
          transition: all 0.3s ease;
        }

        .search-container:focus-within {
          background: white;
          box-shadow: 0 4px 24px rgba(102, 126, 234, 0.15);
        }

        .search-container svg {
          color: #6c757d;
          flex-shrink: 0;
        }

        .search-input {
          border: none;
          background: none;
          outline: none;
          font-size: 15px;
          width: 100%;
          color: #1a1a2e;
        }

        .search-input::placeholder {
          color: #adb5bd;
        }

        /* Main Container */
        .main-container {
          display: flex;
          flex: 1;
          overflow: hidden;
        }

        /* Sidebar */
        .sidebar {
          width: 280px;
          background: rgba(255, 255, 255, 0.7);
          backdrop-filter: blur(20px);
          border-right: 1px solid rgba(0, 0, 0, 0.06);
          padding: 32px 24px;
          display: flex;
          flex-direction: column;
          gap: 24px;
          overflow-y: auto;
        }

        .sidebar-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .sidebar-btn {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          background: transparent;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          font-size: 15px;
          font-weight: 500;
          color: #495057;
          transition: all 0.2s ease;
          text-align: left;
        }

        .sidebar-btn:hover {
          background: rgba(102, 126, 234, 0.08);
          color: #667eea;
          transform: translateX(4px);
        }

        .sidebar-btn.active {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
        }

        .sidebar-divider {
          height: 1px;
          background: rgba(0, 0, 0, 0.06);
          margin: 8px 0;
        }

        .sidebar-label {
          font-size: 12px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.8px;
          color: #adb5bd;
          margin-bottom: 8px;
        }

        .storage-info {
          padding: 16px;
          background: rgba(102, 126, 234, 0.05);
          border-radius: 10px;
          margin-top: 8px;
        }

        .storage-bar {
          height: 6px;
          background: rgba(0, 0, 0, 0.08);
          border-radius: 3px;
          overflow: hidden;
          margin-bottom: 8px;
        }

        .storage-used {
          height: 100%;
          background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
          border-radius: 3px;
          transition: width 0.5s ease;
        }

        .storage-text {
          font-size: 13px;
          color: #6c757d;
        }

        /* Content Area */
        .content {
          flex: 1;
          padding: 32px;
          overflow-y: auto;
          animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .breadcrumbs {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 32px;
          flex-wrap: wrap;
        }

        .breadcrumb {
          background: transparent;
          border: none;
          color: #6c757d;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          padding: 6px 12px;
          border-radius: 6px;
          transition: all 0.2s ease;
        }

        .breadcrumb:hover {
          background: rgba(102, 126, 234, 0.08);
          color: #667eea;
        }

        .breadcrumb.active {
          color: #1a1a2e;
          font-weight: 600;
        }

        /* Items Container */
        .items-container {
          display: grid;
          gap: 20px;
        }

        .items-container.grid {
          grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        }

        .items-container.list {
          grid-template-columns: 1fr;
        }

        .item {
          background: white;
          border-radius: 12px;
          padding: 20px;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          border: 1px solid rgba(0, 0, 0, 0.06);
          position: relative;
          overflow: hidden;
        }

        .item::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          opacity: 0;
          transition: opacity 0.3s ease;
        }

        .item:hover::before {
          opacity: 0.03;
        }

        .item:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 40px rgba(0, 0, 0, 0.08);
          border-color: rgba(102, 126, 234, 0.2);
        }

        .items-container.grid .item {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 12px;
        }

        .items-container.list .item {
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: 16px;
          padding: 16px 20px;
        }

        .item-icon {
          color: #667eea;
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .folder-item .item-icon {
          color: #ffa500;
        }

        .item-info {
          flex: 1;
          position: relative;
          z-index: 1;
        }

        .items-container.list .item-info {
          text-align: left;
        }

        .item-name {
          font-weight: 600;
          color: #1a1a2e;
          font-size: 15px;
          margin-bottom: 4px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .item-size, .item-type {
          font-size: 13px;
          color: #6c757d;
        }

        .item-actions {
          display: flex;
          gap: 8px;
          position: relative;
          z-index: 1;
        }

        /* Empty State */
        .empty-state {
          text-align: center;
          padding: 80px 20px;
          color: #adb5bd;
        }

        .empty-state svg {
          margin-bottom: 24px;
          opacity: 0.3;
        }

        .empty-state h3 {
          font-family: 'Crimson Pro', serif;
          font-size: 24px;
          font-weight: 600;
          color: #6c757d;
          margin-bottom: 8px;
        }

        .empty-state p {
          font-size: 14px;
          color: #adb5bd;
        }

        /* Buttons */
        .btn-icon {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: transparent;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          color: #495057;
          transition: all 0.2s ease;
        }

        .btn-icon:hover {
          background: rgba(102, 126, 234, 0.08);
          color: #667eea;
        }

        .btn-icon-small {
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: transparent;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          color: #6c757d;
          transition: all 0.2s ease;
        }

        .btn-icon-small:hover {
          background: rgba(102, 126, 234, 0.08);
          color: #667eea;
        }

        .btn-primary {
          padding: 12px 24px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 10px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
        }

        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 24px rgba(102, 126, 234, 0.4);
        }

        /* Modal */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          animation: fadeIn 0.2s ease;
        }

        .modal {
          background: white;
          border-radius: 16px;
          width: 90%;
          max-width: 500px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
          padding: 24px 24px 16px;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .modal-header h2 {
          font-family: 'Crimson Pro', serif;
          font-size: 24px;
          font-weight: 600;
          color: #1a1a2e;
        }

        .modal-body {
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .upload-zone {
          border: 2px dashed rgba(102, 126, 234, 0.3);
          border-radius: 12px;
          padding: 48px 24px;
          text-align: center;
          background: rgba(102, 126, 234, 0.02);
          transition: all 0.3s ease;
        }

        .upload-zone:hover {
          border-color: rgba(102, 126, 234, 0.5);
          background: rgba(102, 126, 234, 0.05);
        }

        .upload-zone svg {
          color: #667eea;
          margin-bottom: 16px;
        }

        .upload-zone p {
          color: #6c757d;
          margin-bottom: 20px;
          font-size: 15px;
        }

        .file-input {
          display: none;
        }

        .input {
          width: 100%;
          padding: 14px 16px;
          border: 1px solid rgba(0, 0, 0, 0.12);
          border-radius: 10px;
          font-size: 15px;
          outline: none;
          transition: all 0.2s ease;
          font-family: 'DM Sans', sans-serif;
        }

        .input:focus {
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }

        ::-webkit-scrollbar-track {
          background: transparent;
        }

        ::-webkit-scrollbar-thumb {
          background: rgba(0, 0, 0, 0.15);
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: rgba(0, 0, 0, 0.25);
        }

        /* Responsive */
        @media (max-width: 768px) {
          .sidebar {
            display: none;
          }

          .header {
            padding: 0 16px;
          }

          .content {
            padding: 16px;
          }

          .items-container.grid {
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
          }

          .search-container {
            max-width: 400px;
          }
        }
      `}</style>
    </div>
  );
};

export default FileManager;
