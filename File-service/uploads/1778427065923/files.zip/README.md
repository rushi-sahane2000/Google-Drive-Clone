# CloudVault - Professional File Manager UI

A modern, distinctive file management interface for your Google Drive-like microservices architecture.

## 🎨 Design Features

- **Refined Editorial Aesthetic**: Clean, sophisticated design with unique typography
- **Responsive Layout**: Works seamlessly on desktop and mobile devices
- **Smooth Animations**: Delightful micro-interactions and transitions
- **Grid & List Views**: Toggle between different viewing modes
- **Real-time Search**: Fast file and folder search functionality
- **Drag & Drop Ready**: Easy to extend with drag-and-drop upload

## 🚀 Quick Start

### Prerequisites

- Node.js 16+
- Your backend services running on:
  - File Service: `http://localhost:8081`
  - Folder Service: `http://localhost:8082`
  - Search Service: `http://localhost:8083`

### Installation

1. **Create a new React app** (if you don't have one):

```bash
npx create-react-app cloudvault
cd cloudvault
```

2. **Install dependencies**:

```bash
npm install lucide-react
```

3. **Copy the component**:

Replace `src/App.js` with the provided `file-manager-ui.jsx` content.

4. **Start the development server**:

```bash
npm start
```

The app will open at `http://localhost:3000`

## 🔧 Configuration

### Backend API URLs

Update the `API_BASE` object in the component to match your backend URLs:

```javascript
const API_BASE = {
  files: 'http://localhost:8081/api/files',
  folders: 'http://localhost:8082/api/folders',
  search: 'http://localhost:8083/api/search'
};
```

### CORS Configuration

Ensure your backend services have CORS enabled (already configured in your CorsConfig files). If you're running on different ports, update the `allowedOriginPatterns` to include `http://localhost:3000`.

## 📋 Features

### ✅ Implemented

- **File Operations**
  - Upload files to specific folders
  - Download files
  - View file size and metadata
  - Delete files (UI ready, needs backend integration)

- **Folder Operations**
  - Create new folders
  - Navigate folder hierarchy
  - View folder contents
  - Delete folders (UI ready, needs backend integration)

- **Navigation**
  - Breadcrumb navigation
  - Home/root folder access
  - Parent folder navigation

- **Search**
  - Real-time search across files and folders
  - Search results highlighting

- **UI Features**
  - Grid and list view toggle
  - Responsive sidebar
  - Modal dialogs for actions
  - Loading states and animations

### 🎯 Easy Extensions

1. **Add File Preview**:
   - Integrate PDF.js for PDF preview
   - Add image lightbox for image files
   - Use react-pdf-viewer or similar

2. **Drag & Drop Upload**:

```javascript
const handleDrop = (e) => {
  e.preventDefault();
  const files = e.dataTransfer.files;
  // Upload logic here
};
```

3. **File Selection & Batch Operations**:

```javascript
const [selectedItems, setSelectedItems] = useState([]);
// Implement multi-select with Shift/Ctrl
```

4. **Context Menus**:

```javascript
// Right-click menu for files/folders
// Copy, move, rename, share options
```

5. **File Sharing**:

```javascript
// Generate shareable links
// Set permissions (view, edit)
```

## 🎨 Customization

### Change Color Scheme

Update the gradient colors in the CSS:

```css
/* Primary gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Change to your brand colors */
background: linear-gradient(135deg, #your-color-1 0%, #your-color-2 100%);
```

### Change Typography

The UI uses:
- **Display Font**: Crimson Pro (serif, elegant)
- **Body Font**: DM Sans (sans-serif, modern)

Update in the `@import` statement:

```css
@import url('https://fonts.googleapis.com/css2?family=YourFont&display=swap');
```

### Modify Layout

- **Sidebar width**: Change `.sidebar { width: 280px }`
- **Grid columns**: Modify `minmax(200px, 1fr)`
- **Spacing**: Update padding values

## 🔌 Backend Integration Checklist

Ensure your backend services support these endpoints:

### File Service (Port 8081)
- ✅ `GET /api/files` - Get all files
- ✅ `GET /api/files/{id}` - Get file by ID
- ✅ `GET /api/files/folder/{folderId}` - Get files in folder
- ✅ `POST /api/files/upload` - Upload file
- ✅ `GET /api/files/download/{id}` - Download file
- ✅ `DELETE /api/files/{id}` - Delete file

### Folder Service (Port 8082)
- ✅ `GET /api/folders` - Get all folders
- ✅ `GET /api/folders/{id}` - Get folder by ID
- ✅ `GET /api/folders/parent/{parentId}` - Get subfolders
- ✅ `POST /api/folders/create` - Create folder
- ✅ `DELETE /api/folders/{id}` - Delete folder

### Search Service (Port 8083)
- ✅ `GET /api/search?query=` - Search files and folders
- ✅ `GET /api/search/files?query=` - Search files only
- ✅ `GET /api/search/folder?query=` - Search folders only

## 🐛 Troubleshooting

### CORS Errors

If you see CORS errors in the browser console:

1. Check your backend CorsConfig allows `http://localhost:3000`
2. Ensure the backend is running
3. Try using a proxy in `package.json`:

```json
{
  "proxy": "http://localhost:8081"
}
```

### File Upload Not Working

1. Check backend accepts `multipart/form-data`
2. Verify the upload directory exists and is writable
3. Check file size limits in backend configuration

### Search Not Returning Results

1. Verify the search service can reach file and folder services
2. Check Feign client URLs are correct (http vs https)
3. Ensure data exists in the database

## 📦 Production Build

```bash
npm run build
```

Deploy the `build` folder to your web server or hosting platform:
- Netlify
- Vercel
- AWS S3 + CloudFront
- Your own server with nginx

## 🔒 Security Notes

For production deployment:

1. **Environment Variables**: Move API URLs to `.env` files
2. **Authentication**: Add JWT token handling
3. **HTTPS**: Use HTTPS for all API communication
4. **File Validation**: Validate file types and sizes on both frontend and backend
5. **Rate Limiting**: Implement API rate limiting

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 🎯 Next Steps

1. Add user authentication and authorization
2. Implement file sharing and permissions
3. Add file preview capabilities
4. Integrate cloud storage (AWS S3, Google Cloud Storage)
5. Add real-time collaboration features
6. Implement version control for files
7. Add activity logs and audit trails

## 📄 License

This UI component is provided as-is for your project.

## 🤝 Support

For issues or questions, refer to your backend service documentation or React documentation.

---

**Built with React, Lucide Icons, and modern CSS**
