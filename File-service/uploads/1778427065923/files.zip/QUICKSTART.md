# Quick Start Guide - CloudVault File Manager

## 🚀 Setup in 5 Minutes

### Option 1: Add to Existing React App

If you already have a React app:

1. **Install Lucide Icons**:
```bash
npm install lucide-react
```

2. **Copy the component**:
   - Copy `file-manager-ui.jsx` to your `src` folder
   - Rename it to `FileManager.jsx` (optional)

3. **Use in your app**:
```javascript
// In your App.js
import FileManager from './file-manager-ui';

function App() {
  return <FileManager />;
}

export default App;
```

4. **Update API URLs** if your backend runs on different ports:
```javascript
const API_BASE = {
  files: 'http://your-domain:8081/api/files',
  folders: 'http://your-domain:8082/api/folders',
  search: 'http://your-domain:8083/api/search'
};
```

5. **Start your app**:
```bash
npm start
```

---

### Option 2: Create New React App from Scratch

1. **Create React app**:
```bash
npx create-react-app cloudvault-ui
cd cloudvault-ui
```

2. **Install dependencies**:
```bash
npm install lucide-react
```

3. **Replace files**:
   - Copy `file-manager-ui.jsx` to `src/`
   - Copy `index.js` to `src/` (replaces existing)
   - Copy `index.html` to `public/` (replaces existing)

4. **Project structure should look like**:
```
cloudvault-ui/
├── public/
│   ├── index.html          ← Use provided file
│   └── ...
├── src/
│   ├── file-manager-ui.jsx ← Main component
│   ├── index.js            ← Use provided file
│   └── ...
├── package.json
└── README.md
```

5. **Start the app**:
```bash
npm start
```

App opens at: `http://localhost:3000`

---

## 🔧 Backend Requirements

Before starting the frontend, ensure your backend services are running:

### Start your Java services:

1. **File Service** (Port 8081):
```bash
cd File-service
./mvnw spring-boot:run
```

2. **Folder Service** (Port 8082):
```bash
cd Folder-Service
./mvnw spring-boot:run
```

3. **Search Service** (Port 8083):
```bash
cd search-service
./mvnw spring-boot:run
```

### Verify services are running:
- File Service: `http://localhost:8081/api/files`
- Folder Service: `http://localhost:8082/api/folders`
- Search Service: `http://localhost:8083/api/search`

---

## ✅ Testing the Integration

1. **Open the UI**: `http://localhost:3000`

2. **Create a folder**:
   - Click "New Folder" in sidebar
   - Enter a name (e.g., "Documents")
   - Click "Create Folder"

3. **Upload a file**:
   - Click "Upload" in sidebar
   - Select a file from your computer
   - File appears in the current folder

4. **Test search**:
   - Type in the search bar
   - See real-time filtered results

5. **Navigate folders**:
   - Click on a folder to open it
   - Use breadcrumbs to go back
   - Click "Home" to return to root

6. **Download a file**:
   - In list view, click the download icon
   - File downloads to your computer

---

## 🎨 Customization Quick Tips

### Change Brand Colors:

Find this in `file-manager-ui.jsx` (around line 700):

```css
/* Replace this gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* With your brand colors */
background: linear-gradient(135deg, #yourColor1 0%, #yourColor2 100%);
```

Apply to:
- `.logo-icon`
- `.sidebar-btn.active`
- `.btn-primary`
- `.storage-used`

### Change App Name:

1. In `index.html`: Change `<title>CloudVault</title>`
2. In `file-manager-ui.jsx`: Change `<span className="logo-text">CloudVault</span>`

---

## 🐛 Common Issues

### Issue: CORS Error

**Solution**: Your backend CorsConfig should allow `http://localhost:3000`:

```java
@Override
public void addCorsMappings(CorsRegistry registry) {
    registry.addMapping("/**")
            .allowedOrigins("http://localhost:3000")  // Add this
            .allowedOriginPatterns("*")
            .allowedHeaders("*")
            .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
            .allowCredentials(true);
}
```

### Issue: Files/Folders Not Loading

**Checklist**:
- [ ] Backend services running?
- [ ] API URLs correct in component?
- [ ] Check browser console for errors
- [ ] Database connected and populated?

### Issue: Upload Fails

**Check**:
- [ ] Upload directory exists: `File-service/uploads/`
- [ ] Directory has write permissions
- [ ] File size within limits
- [ ] Backend accepts multipart/form-data

---

## 📱 Features Checklist

After setup, you should be able to:

- [x] View all files and folders
- [x] Navigate folder hierarchy
- [x] Create new folders
- [x] Upload files
- [x] Download files
- [x] Search files and folders
- [x] Switch between grid and list views
- [x] See file sizes
- [x] Use breadcrumb navigation

---

## 🎯 Next Steps

Once everything works:

1. **Add Authentication**: Integrate JWT tokens
2. **File Preview**: Add PDF/image preview
3. **Drag & Drop**: Implement drag-and-drop upload
4. **File Sharing**: Add share functionality
5. **Permissions**: Implement user permissions
6. **Themes**: Add dark mode toggle

---

## 📞 Need Help?

- Check the full README.md for detailed documentation
- Review your backend service logs
- Check browser console for frontend errors
- Verify network requests in browser DevTools

**Ready to build something amazing! 🚀**
