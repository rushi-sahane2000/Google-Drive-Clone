package com.cfs.Eureka_Client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
