package com.CFS.DockerP02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerP02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
