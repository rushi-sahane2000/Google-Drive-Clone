package com.CFS.DockerP02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerP02Application {

	public static void main(String[] args) {
		SpringApplication.run(DockerP02Application.class, args);
	}

}
